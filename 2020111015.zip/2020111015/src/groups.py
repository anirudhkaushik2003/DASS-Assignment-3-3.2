from sprite import *
building_group = Sprite.Group()
barbarian_group = Sprite.Group()
bullet_group = Sprite.Group()
wall_group = Sprite.Group()
balloon_group = Sprite.Group()
arrow_group = Sprite.Group()
BigBullet_group = Sprite.Group()
queen_arrow_group = Sprite.Group()